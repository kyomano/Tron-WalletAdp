import { createContext } from "react";

const UserAccountContext = createContext(null);

export default UserAccountContext;