import { createContext } from "react";

const TradeContext = createContext(null);

export default TradeContext;